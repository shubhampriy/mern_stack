package com.course.manager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourseManagerApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(CourseManagerApiApplication.class, args);
    }

}
