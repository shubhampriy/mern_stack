

const base_url="http://localhost:2023/api";
export default base_url;